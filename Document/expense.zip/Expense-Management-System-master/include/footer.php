  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Developed by <a class="text-white" href="http://www.egavilanmedia.com"
          target="_blank"> EGavilan Media</a> | All Rights Reserved. &copy; 2019</p>
    </div>
    <!-- /.container -->
  </footer>
</body>

</html>